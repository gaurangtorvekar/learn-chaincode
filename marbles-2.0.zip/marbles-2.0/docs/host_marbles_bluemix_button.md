#Run Marbles on Bluemix

###Run Marbles with a button
This will create a new marble Node.js application **AND** create a new blockchain service in your Bluemix account.

1. Simply click this button -> &nbsp;&nbsp; 
[![Deploy to Bluemix](https://bluemix.net/deploy/button.png)](https://bluemix.net/deploy?repository=https://github.com/ibm-blockchain/marbles.git)
1. Once you are up and running [continue tutorial 1](./tutorial_part1.md#use).